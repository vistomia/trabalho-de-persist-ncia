import os
import subprocess
import urllib.request

class Server:
    """Classe para gerenciar um servidor de Minecraft."""
    def __init__(self, name, properties_dict=None):
        self.name = name
        self.version = "1.8"
        self.path = name
        self.process = None
        self.running = False
        self.properties_dict = properties_dict
    
    @staticmethod
    def server_exists(name) -> bool:
        return os.path.exists(name)

    def __enter__(self):
        os.makedirs(self.path, exist_ok=True)
        os.chdir(self.path)
        return self
    
    def __exit__(self, exc_type, exc_value, traceback):
        os.chdir("..")
        pass

    def download_server_jar(self):
        url = "https://launcher.mojang.com/v1/objects/a028f00e678ee5c6aef0e29656dca091b5df11c7/server.jar"
        filename = "server.jar"
        urllib.request.urlretrieve(url, filename)

    def run_core(self):
        self.running = True
        self.process = subprocess.Popen(["java", "-jar", "server.jar", "nogui"], stdin=subprocess.PIPE, text=True)

    def stop_core(self):
        self.running = False
        if self.process:
            self.process.stdin.write("stop\n")
            self.process.stdin.flush()
            self.process.wait()
            print("Server stopped.")
            self.process = None

    def kill_core(self):
        self.running = False
        if self.process:
            self.process.kill()
            print("Server killed.")
            self.process = None
    
    def execute_command(self, command):
        if self.running and self.process:
            self.process.stdin.write(command + "\n")
            self.process.stdin.flush()

    def eula(self):
        with open("eula.txt", "w") as f:
            f.write("eula=true\n")
    
    def properties(self, properties_dict):
        with open("server.properties", "w") as f:
            for key, value in properties_dict.items():
                f.write(f"{key}={value}\n")
