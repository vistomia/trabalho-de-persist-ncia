# Trabalho

Gerenciador de Servidores e Usuários com API RESTful

Não consegui implementar a funcionalidade de login de usuário devido a limitações de tempo e pela estrutura dos bancos CSV.